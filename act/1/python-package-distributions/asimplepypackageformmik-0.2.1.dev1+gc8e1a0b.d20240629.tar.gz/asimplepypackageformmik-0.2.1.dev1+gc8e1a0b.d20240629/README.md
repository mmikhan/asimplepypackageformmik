# Simple Package

A simple Python package for demonstration purposes.

## Installation

```sh
pip install asimplepypackageformmik
```

## Usage

```python
from simple_package import greet

print(greet("World"))  # Output: Hello, World!
```
