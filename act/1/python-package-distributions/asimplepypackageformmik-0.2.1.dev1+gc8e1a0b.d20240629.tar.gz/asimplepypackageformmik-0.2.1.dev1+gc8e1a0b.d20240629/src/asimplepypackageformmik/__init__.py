from .main import greet

__all__ = ['greet']
__version__ = '0.1.0'
